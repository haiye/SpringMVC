package app01a.bean;

public class Dependency {

}
